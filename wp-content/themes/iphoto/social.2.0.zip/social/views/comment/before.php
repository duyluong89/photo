<div class="social-heading">
	<h2 class="social-title social-tab-active"><span><?php echo $tab; ?></span></h2>
</div>
