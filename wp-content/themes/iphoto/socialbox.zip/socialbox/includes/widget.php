<?php
/*
Plugin Name: 	SocialBox
Plugin URI: 	http://codecanyon.net/item/socialbox-social-wordpress-widget/627127
Description: 	Adds a super easy Social Box Widget which displays the current numbers of Facebook Page Likes, Twitter, Dribbble, Forrst and Digg Followers and YouTube and Vimeo Channel and Feedburner Feed Subscriptions.
Version: 		1.2.1
Author: 		JonasDoebertin
Author URI: 	http://codecanyon.net/user/JonasDoebertin
License: 		Sold exclusively on CodeCanyon
*/
?>

<!-- SocialBox Widget -->
<div id="socialbox">
	
	<ul>
		
		<?php foreach($networks as $network): ?>
			
		<li>
			
			<p>
				<a href="<?php echo $network['link']; ?>" title="<?php echo $network['buttonHint']; ?>" <?php if($newWindow) echo 'target="_blank"'; ?>><img src="<?php $this->url('images/icons/' . $network['type'] . '_16.png'); ?>" alt="<?php echo $network['name']; ?>" /></a><span><?php echo number_format($network['count']); ?></span> <?php echo $network['metric']; ?>
				<?php if($showButtons): ?>
					<a href="<?php echo $network['link']; ?>" class="socialbox-button" title="<?php echo $network['buttonHint']; ?>" <?php if($newWindow) echo 'target="_blank"'; ?>><?php echo $network['buttonText']; ?></a>
				<?php endif; ?>
			</p>
			
		</li>
			
		<?php endforeach; ?>
		
	</ul>
	
</div>
<!-- End SocialBox Widget -->